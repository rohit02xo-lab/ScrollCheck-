plugins {
    id("com.android.application")
    kotlin("android")
}
android { namespace="com.scrollcheck.app"; compileSdk=35
    defaultConfig { applicationId="com.scrollcheck.app"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" }
}
